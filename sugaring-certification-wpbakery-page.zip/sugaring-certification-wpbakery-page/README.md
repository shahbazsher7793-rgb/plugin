# Sugaring Certification WPBakery Page

This is a plugin, not a theme. It keeps the active Salient Child Theme intact.

1. Upload and activate the plugin from **Plugins → Add New → Upload Plugin**.
2. Create a new page and select the blank/full-width Salient page template.
3. Open **WPBakery Page Builder** and add the **Sugaring Certification Landing** element from the Content category.
4. Edit all fields, images, reviews and FAQs in the element settings. Update the contact form area with the existing Forms plugin shortcode if live submissions are needed.

Do not activate a different theme.
